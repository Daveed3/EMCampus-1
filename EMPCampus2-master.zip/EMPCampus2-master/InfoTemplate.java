package com.example.davet.beach1;

/**
 * Created by davet on 4/22/2017.
 */

public interface InfoTemplate {
    public String getSchoolName();
    public String getAddress();
    public String getNumString();
    public int getNumInt();

}